package com.example.bill;

import android.app.Application;
import android.util.Log;

public class MainApplication extends Application {
    private final static String TAG = "MainApplication";
    public static int goodsCount = 0;
    // 声明一个当前应用的静态实例
    private static MainApplication mApp;

    // 利用单例模式获取当前应用的唯一实例
    public static MainApplication getInstance() {
        return mApp;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
        mApp = this;
    }

    @Override
    public void onTerminate() {
        Log.d(TAG, "onTerminate");
        super.onTerminate();
    }


}
